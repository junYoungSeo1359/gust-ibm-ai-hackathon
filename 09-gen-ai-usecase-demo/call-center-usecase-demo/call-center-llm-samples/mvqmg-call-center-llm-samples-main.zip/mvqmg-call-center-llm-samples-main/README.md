This repo contains some fictitious call center data. 
It's used as part of the _Automating the Boring Stuff with LLMs_ guided project.
